﻿module EZGUI.Drawing {
    export class TilingSprite {
        constructor(texture: PIXI.Texture, width: number, height: number) {
        }
    }
}